import time
from pynput import keyboard
from pynput.keyboard import Key
from pynput.mouse import Controller

mouse = Controller()

def key_check(key):
	global continueLooping
	try:
		if key.char == 'y':
			continueLooping = True
		if key.char != 'y' and key != keyboard.Key.esc:
			mouse.scroll(dx=0, dy=0)
	except AttributeError:
		print('Check')

def on_release(key):
	global continueLooping

	if key == Key.esc:
		continueLooping = False
		mouse.scroll(dx=0, dy=0)

def scroll_wheel():
	mouse.scroll(dx=0, dy=-10000000000)
continueLooping = False

listener = keyboard.Listener(
    on_press=key_check,
    on_release=on_release)
listener.start()

while True:
	time.sleep(1)
	while continueLooping:
		scroll_wheel()
	
