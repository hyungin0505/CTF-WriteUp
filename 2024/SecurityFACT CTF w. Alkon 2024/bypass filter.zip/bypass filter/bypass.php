<?php

if (isset($_GET['test'])) {
    if (preg_match("/^.*(flag|etc|test|passwd|group|shadow|php|ini|sql|index).*$/im", $_GET['test'])) {
        $message = "nope ~.~! 안전하지 않은 파일 요청입니다.";
    } else if ($_GET['test'] === "phpinfo") {
        ob_start();
        phpinfo();
        $phpinfo = ob_get_clean();
    } else {
        include "./" . str_replace(" ", "", $_GET['test'] . ".php");
    }
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bypass</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background: #333;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        main {
            max-width: 650px; 
            margin: 20px auto;
            padding: 40px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            padding: 10px 15px;
            background: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background: #4cae4c;
        }

        footer {
            text-align: center;
            padding: 20px 0;
            background: #333;
            color: white;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>웹사이트에 오신 것을 환영합니다!</h1>
    </header>
    <main>
        <form method="GET" action="">
            <label for="test">테스트할 파일 이름:</label>
            <input type="text" id="test" name="test" required>
            <button type="submit">제출</button>
        </form>
        <div id="result">
            <?php
            if (isset($message)) {
                echo "<p>$message</p>";
            }
            if (isset($phpinfo)) {
                echo $phpinfo; 
            }
            if (isset($flag)) {
                echo "<p>$flag</p>";
                echo "<img src='./a.gif'>";
            }
            ?>
        </div>
    </main>
</body>
</html>
