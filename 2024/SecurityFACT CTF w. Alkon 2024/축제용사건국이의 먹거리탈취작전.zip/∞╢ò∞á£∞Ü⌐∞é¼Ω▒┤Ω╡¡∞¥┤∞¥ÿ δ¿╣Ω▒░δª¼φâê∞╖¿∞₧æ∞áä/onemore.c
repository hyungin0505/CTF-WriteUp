﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void draw() {
    printf("+--------------------------------------------------------------------+\n");
    printf("|                     Welcome to Konkuk's Festival!                  |\n");
    printf("+--------------------------------------------------------------------+\n");
    printf("|     ____                       _ _         _____ _    ____ _____   |\n");
    printf("|    / ___|  ___  ___ _   _ _ __(_) |_ _   _|  ___/ \\  / ___|_   _|  |\n");
    printf("|    \\___ \\ / _ \\/ __| | | | '__| | __| | | | |_ / _ \\| |     | |    |\n");
    printf("|     ___) |  __/ (__| |_| | |  | | |_| |_| |  _/ ___ \\ |___  | |    |\n");
    printf("|    |____/ \\___|\\___|\\__,_|_|  |_|\\__|\\__, |_|/_/   \\_\\____| |_|    |\n");
    printf("|                                      |___/                         |\n");
    printf("+--------------------------------------------------------------------+\n");
}

void init() {
    draw();
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
}

void get_shell() {
    char* shell= "/bin/sh";
    char* args[2];

    args[0] = shell;
    args[1] = NULL;

    execve("/bin/sh", args, NULL);
}

void exec_func() {
    char buf[0x30];
    int key = 0x0badf00d;
    printf("번호표를 보여주세요: ");
    gets(buf);

    if (key == 0xf1e1d00d) {
        printf("Nice Try!");
    }

    else {
        printf("Access Denied!");
    }
}


int main(int argc, char* argv[]) {
    init();
    exec_func();
    return 0;
}
