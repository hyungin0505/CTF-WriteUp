import importlib
import random as rnd

AAEESS = importlib.import_module('Crypto.Cipher.AES')
Padding = importlib.import_module('Crypto.Util.Padding')

rnd.seed('''
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@!:!@@@@@!!!!@@@@@!:!@@@@@
@@@@@! .!!!;      ;!!!. !@@@@@
@@@@@!  --     .    ~-  !@@@@@
@@@@@@,:     .,-      :,@@@@@@
@@@*!!!  ,,.  .:. ,-.  !!!*@@@
@ !. ~.                .~ .! @
@~   -                  -   ~@
@- .~                    ~. -@
@@!!:     -;      ;-     :!!@@
@@@!~     ;;      ;;     ~;@@@
@@@!      !!;~  ~;!!      !@@@
@@@!    ,:-        -:,    !@@@
@@@!  ,~              ~,  !@@@
@@@; ~.      :,.~-     .~ ;@@@
@@@!~         ..         -!@@@
@@@!                     .!@@@
@@@!~                    ~!@@@
@@@@!.                  .!@@@@
@@@@@;.                .;@@@@@
@@@@@@!;              :!@@@@@@
@@@@@@@@!;-........-!;@@@@@@@@
@@@@@@@! :*****!!**** ~!@@@@@@
@@@@@@! .~!**!::****:~ -@@@@@@
@@@@@!. :  ,;;::;*!. ,  ~@@@@@
@@@@@-  ~    ,;*!     ,  !@@@@
@@@@@-                !  !@@@@
@@@@@- ,              ;  !@@@@
@@@@@!.:              , :!!!!@
@@@@@@!!              ~!!!!!@@
@@@@@@@@              !!~!!@@@
@@@@@@@@,   :::;~:    ;~!@@@@@
@@@@@@@@;     -!     -!=@@@@@@
@@@@@@@@-     -!     .!@@@@@@@
@@@@@@@!      -!      .@@@@@@@
@@@@@@@@!:~~~:!=:~~~:;!@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
''')
secret_key = bytes([rnd.randint(0, 2**8) for _ in range(32)])

reselt = "6b8204ab9f4924b96ff2eaa4c3c7e85fd6151b34f2c558434c4f610d7a4c066e"

from Crypto.Cipher import AES
from Crypto.Util import Padding

# result.txt에서 암호화된 데이터를 읽어들임
encrypted_hex = "6b8204ab9f4924b96ff2eaa4c3c7e85fd6151b34f2c558434c4f610d7a4c066e"

# hex 문자열을 바이트로 변환
encrypted = bytes.fromhex(encrypted_hex)

# AES-ECB 복호화기 생성 및 복호화 수행
decryptor = AES.new(secret_key, AES.MODE_ECB)
decrypted = Padding.unpad(decryptor.decrypt(encrypted), AES.block_size)

# 복호화된 데이터 출력
print("Decrypted data:", decrypted.decode())
