import importlib
import random as rnd

AAEESS = importlib.import_module('Crypto.Cipher.AES')
Padding = importlib.import_module('Crypto.Util.Padding')

rnd.seed('''
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@!:!@@@@@!!!!@@@@@!:!@@@@@
@@@@@! .!!!;      ;!!!. !@@@@@
@@@@@!  --     .    ~-  !@@@@@
@@@@@@,:     .,-      :,@@@@@@
@@@*!!!  ,,.  .:. ,-.  !!!*@@@
@ !. ~.                .~ .! @
@~   -                  -   ~@
@- .~                    ~. -@
@@!!:     -;      ;-     :!!@@
@@@!~     ;;      ;;     ~;@@@
@@@!      !!;~  ~;!!      !@@@
@@@!    ,:-        -:,    !@@@
@@@!  ,~              ~,  !@@@
@@@; ~.      :,.~-     .~ ;@@@
@@@!~         ..         -!@@@
@@@!                     .!@@@
@@@!~                    ~!@@@
@@@@!.                  .!@@@@
@@@@@;.                .;@@@@@
@@@@@@!;              :!@@@@@@
@@@@@@@@!;-........-!;@@@@@@@@
@@@@@@@! :*****!!**** ~!@@@@@@
@@@@@@! .~!**!::****:~ -@@@@@@
@@@@@!. :  ,;;::;*!. ,  ~@@@@@
@@@@@-  ~    ,;*!     ,  !@@@@
@@@@@-                !  !@@@@
@@@@@- ,              ;  !@@@@
@@@@@!.:              , :!!!!@
@@@@@@!!              ~!!!!!@@
@@@@@@@@              !!~!!@@@
@@@@@@@@,   :::;~:    ;~!@@@@@
@@@@@@@@;     -!     -!=@@@@@@
@@@@@@@@-     -!     .!@@@@@@@
@@@@@@@!      -!      .@@@@@@@
@@@@@@@@!:~~~:!=:~~~:;!@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
''')
secret_key = bytes([rnd.randint(0, 2**8) for _ in range(32)])


with open('flag.txt', 'rb') as file:
    data = file.read()
secret_info = data

def result(info, secret_key):
    encryptor = AAEESS.new(secret_key, AAEESS.MODE_ECB)
    encrypted = encryptor.encrypt(Padding.pad(info, AAEESS.block_size))
    with open('result.txt', 'w') as file:
        file.write(encrypted.hex())

result(secret_info, secret_key)
